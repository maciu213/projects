﻿namespace GraWKosci
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            WynikLabel = new Label();
            RzucButton = new Button();
            dice1 = new PictureBox();
            dice2 = new PictureBox();
            dice3 = new PictureBox();
            dice4 = new PictureBox();
            dice5 = new PictureBox();
            dice6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dice1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dice2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dice3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dice4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dice5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dice6).BeginInit();
            SuspendLayout();
            // 
            // WynikLabel
            // 
            WynikLabel.AutoSize = true;
            WynikLabel.Location = new Point(609, 457);
            WynikLabel.Name = "WynikLabel";
            WynikLabel.Size = new Size(40, 15);
            WynikLabel.TabIndex = 0;
            WynikLabel.Text = "Wynik";
            // 
            // RzucButton
            // 
            RzucButton.BackColor = Color.IndianRed;
            RzucButton.Location = new Point(552, 356);
            RzucButton.Name = "RzucButton";
            RzucButton.Size = new Size(149, 52);
            RzucButton.TabIndex = 1;
            RzucButton.Text = "Rzuć kośćmi";
            RzucButton.UseVisualStyleBackColor = false;
            RzucButton.Click += RzucButton_Click;
            // 
            // dice1
            // 
            dice1.Image = Properties.Resources.dice1;
            dice1.Location = new Point(12, 12);
            dice1.Name = "dice1";
            dice1.Size = new Size(191, 192);
            dice1.TabIndex = 2;
            dice1.TabStop = false;
            // 
            // dice2
            // 
            dice2.Image = Properties.Resources.dice2;
            dice2.Location = new Point(209, 12);
            dice2.Name = "dice2";
            dice2.Size = new Size(206, 192);
            dice2.TabIndex = 3;
            dice2.TabStop = false;
            // 
            // dice3
            // 
            dice3.Image = Properties.Resources.dice3;
            dice3.Location = new Point(421, 12);
            dice3.Name = "dice3";
            dice3.Size = new Size(200, 192);
            dice3.TabIndex = 4;
            dice3.TabStop = false;
            // 
            // dice4
            // 
            dice4.Image = Properties.Resources.dice4;
            dice4.Location = new Point(627, 12);
            dice4.Name = "dice4";
            dice4.Size = new Size(207, 192);
            dice4.TabIndex = 5;
            dice4.TabStop = false;
            // 
            // dice5
            // 
            dice5.Image = Properties.Resources.dice5;
            dice5.Location = new Point(849, 12);
            dice5.Name = "dice5";
            dice5.Size = new Size(210, 192);
            dice5.TabIndex = 6;
            dice5.TabStop = false;
            // 
            // dice6
            // 
            dice6.Image = Properties.Resources.dice6;
            dice6.Location = new Point(1065, 12);
            dice6.Name = "dice6";
            dice6.Size = new Size(179, 192);
            dice6.TabIndex = 7;
            dice6.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1256, 605);
            Controls.Add(dice6);
            Controls.Add(dice5);
            Controls.Add(dice4);
            Controls.Add(dice3);
            Controls.Add(dice2);
            Controls.Add(dice1);
            Controls.Add(RzucButton);
            Controls.Add(WynikLabel);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dice1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dice2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dice3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dice4).EndInit();
            ((System.ComponentModel.ISupportInitialize)dice5).EndInit();
            ((System.ComponentModel.ISupportInitialize)dice6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label WynikLabel;
        private Button RzucButton;
        private PictureBox dice1;
        private PictureBox dice2;
        private PictureBox dice3;
        private PictureBox dice4;
        private PictureBox dice5;
        private PictureBox dice6;
    }
}
