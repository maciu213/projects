﻿namespace Logowanie
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            positionInput = new ComboBox();
            label3 = new Label();
            surnameInput = new TextBox();
            label2 = new Label();
            nameInput = new TextBox();
            label1 = new Label();
            groupBox2 = new GroupBox();
            passwordButton = new Button();
            listBox = new CheckedListBox();
            charInput = new TextBox();
            label6 = new Label();
            confirmationButton = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(positionInput);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(surnameInput);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(nameInput);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(234, 197);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Dane pracownika";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // positionInput
            // 
            positionInput.FormattingEnabled = true;
            positionInput.Items.AddRange(new object[] { "Kierownik", "Starszy programista", "Młodszy programista", "Tester" });
            positionInput.Location = new Point(82, 119);
            positionInput.Name = "positionInput";
            positionInput.Size = new Size(121, 23);
            positionInput.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 122);
            label3.Name = "label3";
            label3.Size = new Size(67, 15);
            label3.TabIndex = 4;
            label3.Text = "Stanowisko";
            // 
            // surnameInput
            // 
            surnameInput.Location = new Point(82, 73);
            surnameInput.Name = "surnameInput";
            surnameInput.Size = new Size(134, 23);
            surnameInput.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 76);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 2;
            label2.Text = "Nazwisko";
            // 
            // nameInput
            // 
            nameInput.Location = new Point(82, 27);
            nameInput.Name = "nameInput";
            nameInput.Size = new Size(134, 23);
            nameInput.TabIndex = 1;
            nameInput.TextChanged += nameInput_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 30);
            label1.Name = "label1";
            label1.Size = new Size(30, 15);
            label1.TabIndex = 0;
            label1.Text = "Imię";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(passwordButton);
            groupBox2.Controls.Add(listBox);
            groupBox2.Controls.Add(charInput);
            groupBox2.Controls.Add(label6);
            groupBox2.Location = new Point(293, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(234, 197);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "Generowanie hasła";
            // 
            // passwordButton
            // 
            passwordButton.BackColor = Color.SteelBlue;
            passwordButton.ForeColor = SystemColors.Control;
            passwordButton.Location = new Point(71, 151);
            passwordButton.Name = "passwordButton";
            passwordButton.Size = new Size(95, 26);
            passwordButton.TabIndex = 3;
            passwordButton.Text = "Generuj hasło";
            passwordButton.UseVisualStyleBackColor = false;
            passwordButton.Click += passwordButton_Click;
            // 
            // listBox
            // 
            listBox.BackColor = Color.LightSteelBlue;
            listBox.BorderStyle = BorderStyle.None;
            listBox.FormattingEnabled = true;
            listBox.Items.AddRange(new object[] { "Male i wielkie litery", "Cyfry", "Znaki specjalne" });
            listBox.Location = new Point(9, 73);
            listBox.Name = "listBox";
            listBox.Size = new Size(131, 54);
            listBox.TabIndex = 2;
            // 
            // charInput
            // 
            charInput.Location = new Point(82, 27);
            charInput.Name = "charInput";
            charInput.Size = new Size(134, 23);
            charInput.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 30);
            label6.Name = "label6";
            label6.Size = new Size(67, 15);
            label6.TabIndex = 0;
            label6.Text = "Ile znaków?";
            // 
            // confirmationButton
            // 
            confirmationButton.BackColor = Color.SteelBlue;
            confirmationButton.ForeColor = SystemColors.Control;
            confirmationButton.Location = new Point(150, 226);
            confirmationButton.Name = "confirmationButton";
            confirmationButton.Size = new Size(230, 26);
            confirmationButton.TabIndex = 4;
            confirmationButton.Text = "Zatwierdź";
            confirmationButton.UseVisualStyleBackColor = false;
            confirmationButton.Click += confirmationButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(571, 281);
            Controls.Add(confirmationButton);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox surnameInput;
        private Label label2;
        private TextBox nameInput;
        private Label label1;
        private Label label3;
        private GroupBox groupBox2;
        private CheckedListBox listBox;
        private TextBox charInput;
        private Label label6;
        private Button passwordButton;
        private Button confirmationButton;
        private ComboBox positionInput;
    }
}
