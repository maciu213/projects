namespace Logowanie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Dodaj pracownika";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void confirmationButton_Click(object sender, EventArgs e)
        {
            string name = nameInput.Text;
            string surname = surnameInput.Text;
            string position = positionInput.SelectedItem?.ToString();

            string result = $"Imi�: {name}\nNazwisko: {surname}\nStanowisko: {position}";

            MessageBox.Show(result);

        }

        private void nameInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordButton_Click(object sender, EventArgs e)
        {
            -
        }
    }
}
