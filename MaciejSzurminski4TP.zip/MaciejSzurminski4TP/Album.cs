﻿using System;

namespace YourProjectNamespace
{
    public class Album
    {
        public string Artist { get; set; }
        public string AlbumName { get; set; }
        public int SongsNumber { get; set; }
        public int Year { get; set; }
        public int DownloadNumber { get; set; }
    }
}

