﻿namespace YourProjectNamespace
{
    internal class Album
    {
    }
}