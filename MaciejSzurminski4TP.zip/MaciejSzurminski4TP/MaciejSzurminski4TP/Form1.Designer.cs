﻿using System.Windows.Forms;

namespace MaciejSzurminski4TP
{
    public partial class Form1 : Form
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            LeftButton = new Button();
            RightButton = new Button();
            pictureBox1 = new PictureBox();
            ProducerName = new Label();
            AlbumTitle = new Label();
            SongNumber = new Label();
            ReleaseYear = new Label();
            DownloadNumber = new Label();
            PobierzButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // LeftButton
            // 
            LeftButton.BackgroundImage = Properties.Resources.obraz3;
            LeftButton.Location = new Point(23, 111);
            LeftButton.Name = "LeftButton";
            LeftButton.Size = new Size(100, 70);
            LeftButton.TabIndex = 0;
            LeftButton.UseVisualStyleBackColor = true;
            // 
            // RightButton
            // 
            RightButton.BackgroundImage = Properties.Resources.obraz2;
            RightButton.Location = new Point(917, 111);
            RightButton.Name = "RightButton";
            RightButton.Size = new Size(100, 70);
            RightButton.TabIndex = 1;
            RightButton.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.obraz;
            pictureBox1.Location = new Point(160, 22);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(200, 200);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // ProducerName
            // 
            ProducerName.Font = new Font("Segoe UI", 50F);
            ProducerName.ForeColor = Color.White;
            ProducerName.Location = new Point(366, 32);
            ProducerName.Name = "ProducerName";
            ProducerName.Size = new Size(484, 98);
            ProducerName.TabIndex = 0;
            ProducerName.Text = "ProducerName";
            // 
            // AlbumTitle
            // 
            AlbumTitle.AutoSize = true;
            AlbumTitle.Font = new Font("Segoe UI", 30F, FontStyle.Italic, GraphicsUnit.Point, 238);
            AlbumTitle.ForeColor = Color.White;
            AlbumTitle.Location = new Point(386, 111);
            AlbumTitle.Name = "AlbumTitle";
            AlbumTitle.Size = new Size(209, 54);
            AlbumTitle.TabIndex = 3;
            AlbumTitle.Text = "AlbumTitle";
            // 
            // SongNumber
            // 
            SongNumber.AutoSize = true;
            SongNumber.Font = new Font("Segoe UI", 20F);
            SongNumber.ForeColor = Color.FromArgb(97, 217, 24);
            SongNumber.Location = new Point(386, 165);
            SongNumber.Name = "SongNumber";
            SongNumber.Size = new Size(175, 37);
            SongNumber.TabIndex = 4;
            SongNumber.Text = "SongNumber";
            // 
            // ReleaseYear
            // 
            ReleaseYear.AutoSize = true;
            ReleaseYear.Font = new Font("Segoe UI", 20F);
            ReleaseYear.ForeColor = Color.FromArgb(97, 217, 24);
            ReleaseYear.Location = new Point(583, 165);
            ReleaseYear.Name = "ReleaseYear";
            ReleaseYear.Size = new Size(156, 37);
            ReleaseYear.TabIndex = 5;
            ReleaseYear.Text = "ReleaseYear";
            // 
            // DownloadNumber
            // 
            DownloadNumber.AutoSize = true;
            DownloadNumber.Font = new Font("Segoe UI", 20F);
            DownloadNumber.ForeColor = Color.FromArgb(97, 217, 24);
            DownloadNumber.Location = new Point(71, 236);
            DownloadNumber.Name = "DownloadNumber";
            DownloadNumber.Size = new Size(237, 37);
            DownloadNumber.TabIndex = 6;
            DownloadNumber.Text = "DownloadNumber";
            // 
            // PobierzButton
            // 
            PobierzButton.BackColor = Color.FromArgb(97, 217, 24);
            PobierzButton.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 238);
            PobierzButton.Location = new Point(314, 228);
            PobierzButton.Name = "PobierzButton";
            PobierzButton.Size = new Size(125, 54);
            PobierzButton.TabIndex = 7;
            PobierzButton.Text = "Pobierz";
            PobierzButton.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SeaGreen;
            ClientSize = new Size(1048, 302);
            Controls.Add(PobierzButton);
            Controls.Add(DownloadNumber);
            Controls.Add(ReleaseYear);
            Controls.Add(SongNumber);
            Controls.Add(AlbumTitle);
            Controls.Add(ProducerName);
            Controls.Add(pictureBox1);
            Controls.Add(RightButton);
            Controls.Add(LeftButton);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button LeftButton;
        private Button RightButton;
        private PictureBox pictureBox1;
        private Label ProducerName;
        private Label AlbumTitle;
        private Label SongNumber;
        private Label ReleaseYear;
        private Label DownloadNumber;
        private Button PobierzButton;
    }
}
