using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace YourProjectNamespace // Zmie� na nazw� swojej przestrzeni nazw
{
    public partial class Form1 : Form
    {
        private List<Album> albums = new List<Album>();
        private int currentAlbumIndex = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filePath = @"Data.txt"; // Upewnij si�, �e plik Data.txt jest w tym samym katalogu co aplikacja
            LoadAlbums(filePath);
        }

        private void LoadAlbums(string filePath)
        {
            if (File.Exists(filePath))
            {
                try
                {
                    string[] lines = File.ReadAllLines(filePath);
                    Album album = null;

                    foreach (string line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line) || line.Trim() == "{" || line.Trim() == "}")
                            continue;

                        var parts = line.Split(new[] { ':' }, 2);
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim();
                            string value = parts[1].Trim().Trim('"');

                            if (album == null) album = new Album();

                            switch (key)
                            {
                                case "artist":
                                    album.Artist = value;
                                    break;
                                case "album":
                                    album.AlbumName = value;
                                    break;
                                case "songsNumber":
                                    album.SongsNumber = int.Parse(value);
                                    break;
                                case "year":
                                    album.Year = int.Parse(value);
                                    break;
                                case "downloadNumber":
                                    album.DownloadNumber = int.Parse(value);
                                    break;
                            }

                            // Je�li sko�czono wczytywanie pojedynczego albumu, dodaj go do listy
                            if (line.Trim() == "}")
                            {
                                albums.Add(album);
                                album = null; // Nowy obiekt na kolejny album
                            }
                        }
                    }

                    // Poka� pierwszy album po wczytaniu danych
                    if (albums.Count > 0)
                    {
                        currentAlbumIndex = 0; // Ustaw indeks na pierwszy album
                        DisplayAlbum(currentAlbumIndex); // Wy�wietl pierwszy album
                    }
                    else
                    {
                        MessageBox.Show("Brak album�w do wy�wietlenia!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Wyst�pi� b��d podczas wczytywania pliku: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Plik nie istnieje!");
            }
        }

        private void DisplayAlbum(int index)
        {
            if (index >= 0 && index < albums.Count)
            {
                var album = albums[index];
                ProducerName.Text = $"Artist: {album.Artist}";
                AlbumTitle.Text = $"Album: {album.AlbumName}";
                SongNumber.Text = $"Number of Songs: {album.SongsNumber}";
                ReleaseYear.Text = $"Year: {album.Year}";
                DownloadNumber.Text = $"Downloads: {album.DownloadNumber}";
            }
        }

        private void LeftButton_Click(object sender, EventArgs e)
        {
            if (currentAlbumIndex > 0)
            {
                currentAlbumIndex--;
                DisplayAlbum(currentAlbumIndex);
            }
            else
            {
                MessageBox.Show("Jeste� na pierwszym albumie!");
            }
        }

        private void RightButton_Click(object sender, EventArgs e)
        {
            if (currentAlbumIndex < albums.Count - 1)
            {
                currentAlbumIndex++;
                DisplayAlbum(currentAlbumIndex);
            }
            else
            {
                MessageBox.Show("Jeste� na ostatnim albumie!");
            }
        }

        private void PobierzButton_Click(object sender, EventArgs e)
        {
            // Logika do pobierania danych, je�li potrzebna
            MessageBox.Show("Pobieranie danych...");
        }

        // Klasa Album zdefiniowana w tym samym pliku
        public class Album
        {
            public string Artist { get; set; }
            public string AlbumName { get; set; }
            public int SongsNumber { get; set; }
            public int Year { get; set; }
            public int DownloadNumber { get; set; }
        }

        // Automatycznie generowany kod do inicjalizacji komponent�w
        private void InitializeComponent()
        {
            this.LeftButton = new System.Windows.Forms.Button();
            this.RightButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ProducerName = new System.Windows.Forms.Label();
            this.AlbumTitle = new System.Windows.Forms.Label();
            this.SongNumber = new System.Windows.Forms.Label();
            this.ReleaseYear = new System.Windows.Forms.Label();
            this.DownloadNumber = new System.Windows.Forms.Label();
            this.PobierzButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();

            // 
            // LeftButton
            // 
            this.LeftButton.Location = new System.Drawing.Point(15, 100);
            this.LeftButton.Name = "LeftButton";
            this.LeftButton.Size = new System.Drawing.Size(75, 23);
            this.LeftButton.TabIndex = 1;
            this.LeftButton.Text = "Previous";
            this.LeftButton.UseVisualStyleBackColor = true;
            this.LeftButton.Click += new System.EventHandler(this.LeftButton_Click);

            // 
            // RightButton
            // 
            this.RightButton.Location = new System.Drawing.Point(100, 100);
            this.RightButton.Name = "RightButton";
            this.RightButton.Size = new System.Drawing.Size(75, 23);
            this.RightButton.TabIndex = 2;
            this.RightButton.Text = "Next";
            this.RightButton.UseVisualStyleBackColor = true;
            this.RightButton.Click += new System.EventHandler(this.RightButton_Click);

            // 
            // PobierzButton
            // 
            this.PobierzButton.Location = new System.Drawing.Point(185, 100);
            this.PobierzButton.Name = "PobierzButton";
            this.PobierzButton.Size = new System.Drawing.Size(75, 23);
            this.PobierzButton.TabIndex = 3;
            this.PobierzButton.Text = "Pobierz";
            this.PobierzButton.UseVisualStyleBackColor = true;
            this.PobierzButton.Click += new System.EventHandler(this.PobierzButton_Click);

            // 
            // PictureBox
            // 
            this.pictureBox1.Location = new System.Drawing.Point(15, 130);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 150);

            // 
            // ProducerName
            // 
            this.ProducerName.AutoSize = true;
            this.ProducerName.Location = new System.Drawing.Point(15, 20);
            this.ProducerName.Name = "ProducerName";
            this.ProducerName.Size = new System.Drawing.Size(35, 13);
            this.ProducerName.TabIndex = 0;

            // 
            // AlbumTitle
            // 
            this.AlbumTitle.AutoSize = true;
            this.AlbumTitle.Location = new System.Drawing.Point(15, 40);
            this.AlbumTitle.Name = "AlbumTitle";
            this.AlbumTitle.Size = new System.Drawing.Size(35, 13);
            this.AlbumTitle.TabIndex = 0;

            // 
            // SongNumber
            // 
            this.SongNumber.AutoSize = true;
            this.SongNumber.Location = new System.Drawing.Point(15, 60);
            this.SongNumber.Name = "SongNumber";
            this.SongNumber.Size = new System.Drawing.Size(35, 13);
            this.SongNumber.TabIndex = 0;

            // 
            // ReleaseYear
            // 
            this.ReleaseYear.AutoSize = true;
            this.ReleaseYear.Location = new System.Drawing.Point(15, 80);
            this.ReleaseYear.Name = "ReleaseYear";
            this.ReleaseYear.Size = new System.Drawing.Size(35, 13);
            this.ReleaseYear.TabIndex = 0;

            // 
            // DownloadNumber
            // 
            this.DownloadNumber.AutoSize = true;
            this.DownloadNumber.Location = new System.Drawing.Point(15, 100);
            this.DownloadNumber.Name = "DownloadNumber";
            this.DownloadNumber.Size = new System.Drawing.Size(35, 13);
            this.DownloadNumber.TabIndex = 0;

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(284, 311);
            this.Controls.Add(this.LeftButton);
            this.Controls.Add(this.RightButton);
            this.Controls.Add(this.PobierzButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ProducerName);
            this.Controls.Add(this.AlbumTitle);
            this.Controls.Add(this.SongNumber);
            this.Controls.Add(this.ReleaseYear);
            this.Controls.Add(this.DownloadNumber);
            this.Name = "Form1";
            this.Text = "Album Viewer";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // Deklaracja przycisk�w i innych komponent�w
        private System.Windows.Forms.Button LeftButton;
        private System.Windows.Forms.Button RightButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label ProducerName;
        private System.Windows.Forms.Label AlbumTitle;
        private System.Windows.Forms.Label SongNumber;
        private System.Windows.Forms.Label ReleaseYear;
        private System.Windows.Forms.Label DownloadNumber;
        private System.Windows.Forms.Button PobierzButton;
    }
}

