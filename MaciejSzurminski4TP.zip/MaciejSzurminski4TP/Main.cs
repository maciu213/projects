﻿namespace YourProjectNamespace
{
    public class Album
    {
        public string Artist { get; set; }
        public string AlbumName { get; set; }
        public int SongsNumber { get; set; }
        public int Year { get; set; }
        public int DownloadNumber { get; set; }
    }
}

List<Album> albums = new List<Album>(); // Lista do przechowywania wszystkich albumów
int currentAlbumIndex = 0; // Zmienna do śledzenia bieżącego albumu

private void LoadAlbums(string filePath)
{
    if (File.Exists(filePath))
    {
        try
        {
            string[] lines = File.ReadAllLines(filePath);
            Album album = null;

            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line) || line.Trim() == "{" || line.Trim() == "}")
                    continue;

                var parts = line.Split(new[] { ':' }, 2);
                if (parts.Length == 2)
                {
                    string key = parts[0].Trim();
                    string value = parts[1].Trim().Trim('"');

                    if (album == null) album = new Album();

                    switch (key)
                    {
                        case "artist":
                            album.Artist = value;
                            break;
                        case "album":
                            album.AlbumName = value;
                            break;
                        case "songsNumber":
                            album.SongsNumber = int.Parse(value);
                            break;
                        case "year":
                            album.Year = int.Parse(value);
                            break;
                        case "downloadNumber":
                            album.DownloadNumber = int.Parse(value);
                            break;
                    }

                    // Jeśli skończono wczytywanie pojedynczego albumu, dodaj go do listy
                    if (line.Trim() == "}")
                    {
                        albums.Add(album);
                        album = null; // Nowy obiekt na kolejny album
                    }
                }
            }

            // Pokaż pierwszy album po wczytaniu danych
            if (albums.Count > 0)
            {
                DisplayAlbum(currentAlbumIndex);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Wystąpił błąd podczas wczytywania pliku: {ex.Message}");
        }
    }
    else
    {
        MessageBox.Show("Plik nie istnieje!");
    }
}

private void DisplayAlbum(int index)
{
    if (index >= 0 && index < albums.Count)
    {
        var album = albums[index];
        labelArtist.Text = $"Artist: {album.Artist}";
        labelAlbum.Text = $"Album: {album.AlbumName}";
        labelSongsNumber.Text = $"Number of Songs: {album.SongsNumber}";
        labelYear.Text = $"Year: {album.Year}";
        labelDownloadNumber.Text = $"Downloads: {album.DownloadNumber}";
    }

    private void LeftButton_Click(object sender, EventArgs e)
    {
        if (currentAlbumIndex > 0)
        {
            currentAlbumIndex--;
            DisplayAlbum(currentAlbumIndex);
        }
        else
        {
            MessageBox.Show("Jesteś na pierwszym albumie!");
        }
    }
    private void RightButton_Click(object sender, EventArgs e)
    {
        if (currentAlbumIndex < albums.Count - 1)
        {
            currentAlbumIndex++;
            DisplayAlbum(currentAlbumIndex);
        }
        else
        {
            MessageBox.Show("Jesteś na ostatnim albumie!");
        }
    }
    private void Form1_Load(object sender, EventArgs e)
    {
        string filePath = @"C:\path\to\your\Data.txt"; // Ścieżka do pliku
        LoadAlbums(filePath);
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        string filePath = @"C:\path\to\your\Data.txt"; // Upewnij się, że ta ścieżka jest poprawna
        LoadAlbums(filePath);
    }


}
