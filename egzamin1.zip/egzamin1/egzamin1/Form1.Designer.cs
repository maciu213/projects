﻿namespace egzamin1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            LeftButton = new Button();
            RightButton = new Button();
            imageList1 = new ImageList(components);
            DownloadButton = new Button();
            pictureBox1 = new PictureBox();
            NazwaWykonawcy = new Label();
            TytulAlbumu = new Label();
            LiczbaUtworow = new Label();
            RokWydania = new Label();
            LiczbaPobran = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // LeftButton
            // 
            LeftButton.BackgroundImage = Properties.Resources.obraz3;
            LeftButton.Location = new Point(23, 74);
            LeftButton.Name = "LeftButton";
            LeftButton.Size = new Size(101, 70);
            LeftButton.TabIndex = 0;
            LeftButton.UseVisualStyleBackColor = true;
            LeftButton.Click += button1_Click;
            // 
            // RightButton
            // 
            RightButton.BackgroundImage = Properties.Resources.obraz2;
            RightButton.Location = new Point(1089, 74);
            RightButton.Name = "RightButton";
            RightButton.Size = new Size(101, 70);
            RightButton.TabIndex = 1;
            RightButton.UseVisualStyleBackColor = true;
            RightButton.Click += button2_Click;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // DownloadButton
            // 
            DownloadButton.BackColor = Color.FromArgb(97, 217, 24);
            DownloadButton.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 238);
            DownloadButton.Location = new Point(299, 216);
            DownloadButton.Name = "DownloadButton";
            DownloadButton.Size = new Size(125, 44);
            DownloadButton.TabIndex = 4;
            DownloadButton.Text = "Pobierz";
            DownloadButton.UseVisualStyleBackColor = false;
            DownloadButton.Click += button3_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.obraz;
            pictureBox1.Location = new Point(161, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(199, 201);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // NazwaWykonawcy
            // 
            NazwaWykonawcy.AutoSize = true;
            NazwaWykonawcy.Font = new Font("Segoe UI", 50.25F, FontStyle.Regular, GraphicsUnit.Point, 238);
            NazwaWykonawcy.ForeColor = Color.White;
            NazwaWykonawcy.Location = new Point(366, 9);
            NazwaWykonawcy.Name = "NazwaWykonawcy";
            NazwaWykonawcy.Size = new Size(597, 89);
            NazwaWykonawcy.TabIndex = 6;
            NazwaWykonawcy.Text = "Nazwa_wykonawcy";
            // 
            // TytulAlbumu
            // 
            TytulAlbumu.AutoSize = true;
            TytulAlbumu.Font = new Font("Segoe UI", 30F, FontStyle.Italic, GraphicsUnit.Point, 238);
            TytulAlbumu.ForeColor = Color.White;
            TytulAlbumu.Location = new Point(384, 90);
            TytulAlbumu.Name = "TytulAlbumu";
            TytulAlbumu.Size = new Size(249, 54);
            TytulAlbumu.TabIndex = 7;
            TytulAlbumu.Text = "tytul_albumu";
            // 
            // LiczbaUtworow
            // 
            LiczbaUtworow.AutoSize = true;
            LiczbaUtworow.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 238);
            LiczbaUtworow.ForeColor = Color.FromArgb(97, 217, 24);
            LiczbaUtworow.Location = new Point(384, 152);
            LiczbaUtworow.Name = "LiczbaUtworow";
            LiczbaUtworow.Size = new Size(201, 37);
            LiczbaUtworow.TabIndex = 8;
            LiczbaUtworow.Text = "liczba_utworów";
            // 
            // RokWydania
            // 
            RokWydania.AutoSize = true;
            RokWydania.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 238);
            RokWydania.ForeColor = Color.FromArgb(97, 217, 24);
            RokWydania.Location = new Point(618, 152);
            RokWydania.Name = "RokWydania";
            RokWydania.Size = new Size(165, 37);
            RokWydania.TabIndex = 9;
            RokWydania.Text = "rok_wydania";
            // 
            // LiczbaPobran
            // 
            LiczbaPobran.AutoSize = true;
            LiczbaPobran.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 238);
            LiczbaPobran.ForeColor = Color.FromArgb(97, 217, 24);
            LiczbaPobran.Location = new Point(111, 220);
            LiczbaPobran.Name = "LiczbaPobran";
            LiczbaPobran.Size = new Size(182, 37);
            LiczbaPobran.TabIndex = 10;
            LiczbaPobran.Text = "liczba_pobran";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SeaGreen;
            ClientSize = new Size(1222, 273);
            Controls.Add(LiczbaPobran);
            Controls.Add(RokWydania);
            Controls.Add(LiczbaUtworow);
            Controls.Add(TytulAlbumu);
            Controls.Add(NazwaWykonawcy);
            Controls.Add(pictureBox1);
            Controls.Add(DownloadButton);
            Controls.Add(RightButton);
            Controls.Add(LeftButton);
            Name = "Form1";
            Text = "MojeDźwięki, Wykonał: Maciej Szurmiński";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button LeftButton;
        private Button RightButton;
        private ImageList imageList1;
        private Button DownloadButton;
        private PictureBox pictureBox1;
        private Label NazwaWykonawcy;
        private Label TytulAlbumu;
        private Label LiczbaUtworow;
        private Label RokWydania;
        private Label LiczbaPobran;
    }
}
